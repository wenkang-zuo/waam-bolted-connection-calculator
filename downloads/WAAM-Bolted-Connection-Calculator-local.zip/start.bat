@echo off
setlocal
cd /d "%~dp0" || goto :error
if not exist "start.ps1" goto :error

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1"
if errorlevel 1 goto :error
exit /b 0

:error
echo.
echo The calculator could not start. Check the message above and make sure the ZIP was fully extracted.
pause
exit /b 1
