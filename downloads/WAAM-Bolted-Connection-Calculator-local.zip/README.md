# WAAM Stainless Steel Bolted Connection Calculator: double shear

The local edition evaluates WAAM austenitic and duplex stainless steel
single-bolt, double-shear, bearing-type connections. It compares nominal
resistance and governing plate failure mode predictions from ANSI/AISC 360-22,
ANSI/AISC 370-25, ASCE/SEI 8-22, EN 1993-1-8:2024, EN 1993-1-4:2025, a
literature method, Proposed-gv, and Proposed-av.

## Requirements

- Python 3.10 or later
- A modern web browser

No third-party Python packages are required. The application runs entirely on
the local computer and does not upload calculation data.

## Start on Windows

1. Extract the downloaded ZIP file.
2. Double-click `start.bat` in the extracted folder. The launcher looks for
   Python 3.10 or later, including common Anaconda, Miniconda and Miniforge
   installations.
3. Keep the launcher window open while using the calculator. If the browser
   does not open automatically, go to <http://127.0.0.1:8765/>.

Alternatively, run:

```powershell
.\start.ps1
```

If Python is installed in a different location, open a terminal in the
extracted folder and run `server.py --open` with the full path to that
installation's Python executable.

## Start on macOS or Linux

From the extracted application folder, run:

```bash
python3 server.py --open
```

## Functions

- Single-case prediction
- Excel or CSV batch input
- Excel result export
- Automatic calculation of `b = 2e2`
- Mandatory geometry and material validation
- Proposed-method applicability warnings

The Batch Prediction page provides a downloadable Excel input template. The
output workbook contains the original inputs, resistance and governing-mode
predictions for all eight methods, warnings, and row-specific errors.

## Scope

The calculator covers the plate-related resistance of the inner WAAM stainless
steel plate in non-preloaded, single-bolt, double-shear, bearing-type
connections. Bolt failure, frictional slip, and failure of the outer cover
plates must be checked separately.
