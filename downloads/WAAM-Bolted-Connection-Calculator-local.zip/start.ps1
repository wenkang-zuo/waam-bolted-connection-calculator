$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

if (-not (Test-Path -LiteralPath "server.py" -PathType Leaf)) {
    Write-Error "Extract the entire ZIP and run the launcher from the extracted folder."
    exit 1
}

function Test-Python {
    param([string]$Executable, [string[]]$Arguments = @())

    try {
        & $Executable @Arguments -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' *> $null
        return ($LASTEXITCODE -eq 0)
    } catch {
        return $false
    }
}

$executable = $null
$arguments = @()

foreach ($launcher in @(Get-Command py.exe -CommandType Application -All -ErrorAction SilentlyContinue)) {
    if ($launcher.Source -notlike "*\Microsoft\WindowsApps\*" -and (Test-Python -Executable $launcher.Source -Arguments @("-3"))) {
        $executable = $launcher.Source
        $arguments = @("-3")
        break
    }
}

if (-not $executable) {
    $candidates = @()
    if ($env:CONDA_PREFIX) { $candidates += Join-Path $env:CONDA_PREFIX "python.exe" }
    if ($env:VIRTUAL_ENV) { $candidates += Join-Path $env:VIRTUAL_ENV "Scripts\python.exe" }
    $candidates += @(
        Get-Command python.exe, python3.exe -CommandType Application -All -ErrorAction SilentlyContinue |
            Where-Object { $_.Source -notlike "*\Microsoft\WindowsApps\*" } |
            ForEach-Object Source
    )

    foreach ($base in @($env:USERPROFILE, $env:LOCALAPPDATA, $env:ProgramData, $env:ProgramFiles) | Where-Object { $_ }) {
        foreach ($name in @("Anaconda3", "Miniconda3", "Miniforge3")) {
            $candidates += Join-Path $base "$name\python.exe"
        }
    }

    foreach ($root in @("HKCU:\Software\Python\PythonCore", "HKLM:\Software\Python\PythonCore", "HKLM:\Software\WOW6432Node\Python\PythonCore")) {
        foreach ($version in @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
            $install = Get-Item -LiteralPath ($version.PSPath + "\InstallPath") -ErrorAction SilentlyContinue
            if ($install) {
                $registered = $install.GetValue("ExecutablePath")
                $installDir = $install.GetValue("")
                if ($registered) { $candidates += $registered }
                elseif ($installDir) { $candidates += Join-Path $installDir "python.exe" }
            }
        }
    }

    foreach ($candidate in $candidates | Select-Object -Unique) {
        if ((Test-Path -LiteralPath $candidate -PathType Leaf) -and (Test-Python -Executable $candidate)) {
            $executable = $candidate
            break
        }
    }
}

if (-not $executable) {
    Write-Host "Python 3.10 or later could not be started. Install it from https://www.python.org/downloads/ or run the calculator from an environment with Python."
    exit 1
}

Write-Host "Using Python: $executable"
& $executable @arguments -u server.py --open
exit $LASTEXITCODE
