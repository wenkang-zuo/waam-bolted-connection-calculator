(() => {
  "use strict";

  const form = document.getElementById("batch-form");
  const fileInput = document.getElementById("batch-file");
  const chooseFile = document.getElementById("choose-batch-file");
  const fileName = document.getElementById("batch-file-name");
  const run = document.getElementById("run-batch");
  const status = document.getElementById("batch-status");
  const download = document.getElementById("batch-download");
  let outputUrl;

  function setStatus(message, kind = "") {
    status.textContent = message;
    status.dataset.kind = kind;
  }

  function clearOutput() {
    if (outputUrl) URL.revokeObjectURL(outputUrl);
    outputUrl = undefined;
    download.hidden = true;
    download.removeAttribute("href");
  }

  chooseFile.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", () => {
    fileName.textContent = fileInput.files[0]?.name || "No file selected";
    clearOutput();
    setStatus("");
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (run.disabled) return;
    const file = fileInput.files[0];
    if (!file) {
      setStatus("Choose an Excel or CSV file.", "error");
      chooseFile.focus();
      return;
    }
    const match = /\.(xlsx|csv)$/i.exec(file.name);
    clearOutput();
    if (!match) {
      setStatus("Select an .xlsx or UTF-8 .csv file.", "error");
      return;
    }
    run.disabled = true;
    chooseFile.disabled = true;
    setStatus("Calculating…", "working");

    try {
      const response = await fetch("api/batch", {
        method: "POST",
        headers: { "X-Batch-Format": match[1].toLowerCase() },
        body: file,
      });
      if (!response.ok) {
        const detail = await response.json().catch(() => null);
        throw new Error(detail?.errors?.join(" ") || "Batch calculation failed.");
      }
      const processed = Number(response.headers.get("X-Processed-Rows"));
      const errors = Number(response.headers.get("X-Error-Rows"));
      outputUrl = URL.createObjectURL(await response.blob());
      download.href = outputUrl;
      download.download = "single_shear_batch_results.xlsx";
      download.hidden = false;
      download.click();
      setStatus(
        `Excel results ready. Calculated rows: ${processed}. Rows with validation errors: ${errors}.`,
        errors ? "warning" : "success",
      );
    } catch (error) {
      setStatus(error.message, "error");
    } finally {
      chooseFile.disabled = false;
      run.disabled = false;
    }
  });
})();
