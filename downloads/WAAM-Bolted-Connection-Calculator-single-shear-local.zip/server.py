"""Entry point copied to the root of the single-shear release as server.py."""

from single_shear_local.server import main


if __name__ == "__main__":
    main()
