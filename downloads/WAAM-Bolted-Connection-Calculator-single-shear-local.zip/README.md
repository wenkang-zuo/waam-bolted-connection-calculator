# WAAM Stainless Steel Bolted Connection Calculator: single shear

This local edition evaluates the WAAM stainless steel plate in a non-preloaded,
single-bolt, single-shear bearing-type connection with a standard circular hole
and no washers. It supports single-case prediction and batch calculation. Files
and results are processed on your computer.

## Start the calculator

Requires Python 3.10 or later and a modern browser. No third-party Python
packages are required.

On Windows, extract the entire ZIP and double-click `start.bat` in the extracted
folder. The launcher can use a standard Python installation or a common Conda
installation, including Anaconda. Keep the launcher window open during use.
If the browser does not open, use the address printed in that window, usually
<http://127.0.0.1:18766/>.

On macOS or Linux, open a terminal in the extracted folder and run
`python3 server.py --open`.

## Batch Prediction

1. Download the Excel template from the Batch Prediction tab.
2. Enter one case per row, using millimetres for dimensions and MPa for
   strengths. Keep the template's first-row headers. `Model_ID` is optional.
   Use ASS or DSS for `Material`. Provide either `b_mm` or `e2_mm`, or both if
   they satisfy `b = 2e2`.
3. Select the `.xlsx` or UTF-8 `.csv` file and choose **Calculate and Export Excel**.

For an existing research workbook, the calculator selects `Single_lap_batch`
when present. It also accepts the workbook's `A` and `D` material codes and
`fy_MPa` and `fu_MPa` column names. Save any Excel formulas that supply the
inputs after recalculating the workbook so that their last calculated values
are available.

The exported workbook includes the source row, case identifier, inputs, nominal
resistance in kN and governing mode for each of the five design standards and the
two proposed methods (Proposed-nv and Proposed-gv). Invalid rows are kept with
their error messages and blank predictions. ASCE/SEI 8-22 values for plates thicker
than 4.7625 mm are labelled as comparative in the warnings column.

The single-shear calculator covers plate resistance. Bolt failure, companion
plate failure and frictional slip are outside its scope.
