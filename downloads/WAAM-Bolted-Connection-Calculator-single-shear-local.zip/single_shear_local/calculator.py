"""Nominal plate resistance for a single-shear WAAM stainless steel connection."""

from __future__ import annotations

import math
from collections.abc import Mapping


ASCE_THICKNESS_LIMIT_MM = 4.7625
ASCE_SCOPE_NOTE = "ASCE/SEI 8-22: comparison only (t > 4.7625 mm)."
FIELD_LABELS = {
    "fy": "Yield strength fᵧ",
    "fu": "Ultimate strength fᵤ",
    "t": "Plate thickness t",
    "db": "Nominal bolt diameter dᵦ",
    "dh": "Bolt-hole diameter dₕ",
    "e1": "End distance e₁",
    "e2": "Edge distance e₂",
    "b": "Plate width b",
}


class ValidationError(ValueError):
    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__(" ".join(errors))


def _number(value: object) -> float:
    if not isinstance(value, (str, int, float)) or isinstance(value, bool):
        return math.nan
    try:
        return float(value)
    except (ValueError, OverflowError):
        return math.nan


def normalize_inputs(data: Mapping[str, object]) -> dict[str, float]:
    errors = []
    if str(data.get("material", "")).strip().upper() not in {"ASS", "DSS"}:
        errors.append("Select ASS or DSS for the WAAM plate.")

    values: dict[str, float] = {}
    for key, label in FIELD_LABELS.items():
        raw = data.get(key)
        missing = raw is None or (isinstance(raw, str) and not raw.strip())
        if missing and key in {"b", "e2"}:
            continue
        value = _number(raw)
        if not math.isfinite(value) or value <= 0:
            errors.append(f"{label} must be a positive number.")
        else:
            values[key] = value
    if errors:
        raise ValidationError(errors)

    if "b" not in values and "e2" not in values:
        raise ValidationError(["Enter either plate width b or edge distance e₂."])
    if "b" not in values:
        values["b"] = 2 * values["e2"]
        if not math.isfinite(values["b"]):
            errors.append("The calculated plate width must be finite.")
    elif "e2" not in values:
        values["e2"] = values["b"] / 2
    elif abs(values["b"] / 2 - values["e2"]) > 1e-9 * values["e2"]:
        errors.append("Plate width and edge distance must satisfy b = 2e₂.")

    fy, fu = values["fy"], values["fu"]
    db, dh = values["db"], values["dh"]
    if fy > fu:
        errors.append("Yield strength fᵧ must not exceed ultimate strength fᵤ.")
    if not db.is_integer() or db > 30:
        errors.append("Nominal bolt diameter dᵦ must be a positive whole number up to 30 mm.")
    else:
        if db < 12:
            minimum, maximum = 0.5, 1.5
        elif db <= 23:
            minimum, maximum = 1.5, 2.5
        else:
            minimum, maximum = 2.5, 3.5
        if not minimum <= dh - db <= maximum:
            errors.append(
                f"For dᵦ = {db:g} mm, the hole clearance dₕ − dᵦ must be {minimum:g} to {maximum:g} mm."
            )
    if values["e1"] <= dh / 2:
        errors.append("End distance e₁ must be greater than dₕ / 2.")
    if values["b"] <= dh or values["e2"] <= dh / 2:
        errors.append("Edge distance e₂ must be greater than dₕ / 2 so that b exceeds dₕ.")
    if errors:
        raise ValidationError(errors)
    return values


def evaluate_plate_resistance(
    *, fy: float, fu: float, t: float, db: float, dh: float, e1: float, e2: float, b: float
) -> dict[str, tuple[float, str]]:
    """Evaluate the formulas implemented in online/single-lap/calculator.js."""
    scale = t * fu / 1000
    net_section = (b - dh) * scale
    bearing = db * scale
    net_shear = 2 * (e1 - dh / 2) * scale
    gross_shear = (e1 / dh) * bearing
    wide_edge = e2 / dh > 1.5
    thin_plate = t <= 4

    aisc360_shear = 0.75 * net_shear
    aisc370_shear = (5 / 6) * gross_shear
    aisc370_bearing = (2.5 if wide_edge else 2) * bearing
    asce_net_section = (0.9 + 0.1 * db / b) * net_section
    km = 1 if fy <= 460 else 0.9
    k1 = 1 if wide_edge else 0.8
    ec34_shear = 0.8 * gross_shear if thin_plate else k1 * aisc370_shear
    ec34_bearing = 1.6 * bearing if thin_plate else aisc370_bearing
    proposed_net_section = (0.85 + 0.15 * dh / b) * net_section
    proposed_bearing = 2.2 * bearing

    branches = {
        "AISC360": (net_section, aisc360_shear, 3 * bearing),
        "AISC370": (net_section, aisc370_shear, aisc370_bearing),
        "ASCE8": (asce_net_section, 0.6 * net_shear, 2.65 * 0.75 * bearing),
        "EC3-8": (net_section, km * gross_shear, 1.5 * bearing),
        "EC3-4": (net_section, ec34_shear, ec34_bearing),
        "pro,nv": (proposed_net_section, aisc360_shear, proposed_bearing),
        "pro,gv": (proposed_net_section, 1.1 * gross_shear, proposed_bearing),
    }
    results = {}
    for key, candidates in branches.items():
        if any(not math.isfinite(value) or value <= 0 for value in candidates):
            raise ValidationError(["The entered values exceed the numerical range of the calculator."])
        resistance = min(candidates)
        # Match the browser's NSR, SOF, BF tie order.
        tolerance = 8 * math.ulp(1.0) * resistance
        mode = next(
            name for name, value in zip(("NSR", "SOF", "BF"), candidates)
            if abs(value - resistance) <= tolerance
        )
        results[key] = (resistance, mode)
    return results


def calculate(data: Mapping[str, object]) -> tuple[dict[str, float], dict[str, tuple[float, str]], list[str]]:
    inputs = normalize_inputs(data)
    predictions = evaluate_plate_resistance(**inputs)

    outside = []
    if inputs["e1"] / inputs["dh"] < 1.2:
        outside.append("e₁ / dₕ < 1.2")
    if inputs["e2"] / inputs["dh"] < 1.2:
        outside.append("e₂ / dₕ < 1.2")
    if inputs["t"] > 5:
        outside.append("t > 5 mm")
    warnings = []
    if outside:
        warnings.append(f"Outside the recommended range for the proposed methods ({', '.join(outside)}).")
    if inputs["t"] > ASCE_THICKNESS_LIMIT_MM:
        warnings.append(ASCE_SCOPE_NOTE)
    return inputs, predictions, warnings
