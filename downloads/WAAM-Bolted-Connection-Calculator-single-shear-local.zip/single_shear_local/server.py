"""Serve the offline single-shear calculator and its batch endpoints."""

from __future__ import annotations

import argparse
import csv
import json
import socket
import sys
import threading
import webbrowser
import zipfile
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from xml.etree.ElementTree import ParseError

from single_shear_local.batch import batch_results, template


ROOT = Path(__file__).resolve().parent.parent
PORT = 18766
MAX_UPLOAD_BYTES = 50 * 1024 * 1024
EXCEL_CONTENT_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
STATIC_FILES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
    "/calculator.js": ("calculator.js", "text/javascript; charset=utf-8"),
    "/calculator-tabs.js": ("calculator-tabs.js", "text/javascript; charset=utf-8"),
    "/calculator-ui.css": ("calculator-ui.css", "text/css; charset=utf-8"),
    "/batch.js": ("batch.js", "text/javascript; charset=utf-8"),
    "/batch.css": ("batch.css", "text/css; charset=utf-8"),
}


class LocalServer(ThreadingHTTPServer):
    allow_reuse_address = sys.platform != "win32"

    def server_bind(self) -> None:
        if sys.platform == "win32":
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args: object) -> None:
        print(f"{self.address_string()} - {format % args}", file=sys.stdout, flush=True)

    def _send_bytes(
        self,
        content: bytes,
        content_type: str,
        status: HTTPStatus = HTTPStatus.OK,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(content)

    def _send_json(self, content: object, status: HTTPStatus = HTTPStatus.OK) -> None:
        data = json.dumps(content, ensure_ascii=False).encode("utf-8")
        self._send_bytes(data, "application/json; charset=utf-8", status)

    def _send_error_message(self, message: str, status: HTTPStatus) -> None:
        self._send_json({"errors": [message]}, status)

    def do_GET(self) -> None:
        path = urlsplit(self.path).path
        if path == "/api/health":
            self._send_json({"ok": True, "calculator": "single shear"})
        elif path == "/api/template":
            self._send_bytes(
                template(),
                EXCEL_CONTENT_TYPE,
                headers={"Content-Disposition": 'attachment; filename="single_shear_batch_template.xlsx"'},
            )
        elif path in STATIC_FILES:
            filename, content_type = STATIC_FILES[path]
            try:
                content = (ROOT / filename).read_bytes()
            except FileNotFoundError:
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            self._send_bytes(content, content_type)
        else:
            self.send_error(HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        request = urlsplit(self.path)
        if request.path != "/api/batch":
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        # The browser sends a preflight for this custom header on cross-origin requests.
        if self.headers.get("X-Batch-Format") is None:
            self._send_error_message("Open the batch tool from the local calculator.", HTTPStatus.FORBIDDEN)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._send_error_message("Invalid file size.", HTTPStatus.BAD_REQUEST)
            return
        if length <= 0:
            self._send_error_message("Select a nonempty batch file.", HTTPStatus.BAD_REQUEST)
            return
        if length > MAX_UPLOAD_BYTES:
            self._send_error_message("Use a batch file smaller than 50 MB.", HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
            return

        format_name = self.headers["X-Batch-Format"].lower()
        try:
            workbook, processed, errors = batch_results(self.rfile.read(length), f"batch.{format_name}")
        except UnicodeDecodeError:
            self._send_error_message("Save CSV files with UTF-8 encoding.", HTTPStatus.UNPROCESSABLE_ENTITY)
            return
        except (zipfile.BadZipFile, ParseError, IndexError, KeyError, csv.Error):
            self._send_error_message("The batch file could not be read. Check its format.", HTTPStatus.UNPROCESSABLE_ENTITY)
            return
        except ValueError as error:
            self._send_error_message(str(error), HTTPStatus.UNPROCESSABLE_ENTITY)
            return
        self._send_bytes(
            workbook,
            EXCEL_CONTENT_TYPE,
            headers={
                "Content-Disposition": 'attachment; filename="single_shear_batch_results.xlsx"',
                "X-Processed-Rows": str(processed),
                "X-Error-Rows": str(errors),
            },
        )


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the single-shear calculator on this computer.")
    parser.add_argument("--port", type=int)
    parser.add_argument("--open", action="store_true")
    args = parser.parse_args()
    host = "127.0.0.1"
    ports = [args.port] if args.port is not None else range(PORT, PORT + 10)
    for port in ports:
        try:
            server = LocalServer((host, port), Handler)
        except (OSError, OverflowError) as error:
            last_error = error
        else:
            break
    else:
        parser.exit(1, f"Could not start the local calculator: {last_error}\n")

    if args.port is None and server.server_port != PORT:
        print(f"Port {PORT} is unavailable. Using port {server.server_port} instead.", flush=True)

    url = f"http://{host}:{server.server_port}/"
    print(f"Single shear calculator: {url}", flush=True)
    if args.open:
        launch = threading.Timer(0.5, webbrowser.open, args=(url,))
        launch.daemon = True
        launch.start()
    try:
        with server:
            server.serve_forever()
    except KeyboardInterrupt:
        pass
