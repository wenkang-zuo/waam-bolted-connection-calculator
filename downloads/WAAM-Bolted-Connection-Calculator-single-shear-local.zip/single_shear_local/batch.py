"""Read single-shear batch cases and export one result row per input case."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path

from single_shear_local.calculator import ValidationError, calculate
from xlsx_io import read_csv_rows, read_xlsx_rows, write_xlsx


INPUT_COLUMNS = {
    "Model_ID": ("Model_ID", "Case_ID"),
    "Material": ("Material",),
    "fy_MPa_theta": ("fy_MPa_theta", "fy_MPa", "fy"),
    "fu_MPa_theta": ("fu_MPa_theta", "fu_MPa", "fu"),
    "t_mm": ("t_mm", "t"),
    "db_mm": ("db_mm", "db"),
    "dh_mm": ("dh_mm", "dh"),
    "e1_mm": ("e1_mm", "e1"),
    "e2_mm": ("e2_mm", "e2"),
    "b_mm": ("b_mm", "b"),
}
MODEL_FIELDS = {
    "Material": "material",
    "fy_MPa_theta": "fy",
    "fu_MPa_theta": "fu",
    "t_mm": "t",
    "db_mm": "db",
    "dh_mm": "dh",
    "e1_mm": "e1",
    "e2_mm": "e2",
    "b_mm": "b",
}
OUTPUT_COLUMNS = {
    "AISC360": ("PAISC360_u_kN", "Gov_AISC360"),
    "AISC370": ("PAISC370_u_kN", "Gov_AISC370"),
    "ASCE8": ("PASCE8_u_kN", "Gov_ASCE8"),
    "EC3-8": ("PEC3-8_u_kN", "Gov_EC3-8"),
    "EC3-4": ("PEC3-4_u_kN", "Gov_EC3-4"),
    "pro,nv": ("Ppro,nv_u_kN", "Gov_pro,nv"),
    "pro,gv": ("Ppro,gv_u_kN", "Gov_pro,gv"),
}
MATERIAL_CODES = {"A": "ASS", "D": "DSS"}


def template() -> bytes:
    examples = [
        ["ASS-example", "ASS", 350, 550, 3, 18, 20, 40, None, 60],
        ["DSS-example", "DSS", 483.1, 684.2, 5, 24, 27, 40.5, 94.5, None],
    ]
    return write_xlsx(list(INPUT_COLUMNS), examples, "Single_lap_batch", resistance_columns=set())


def _is_present(value: object) -> bool:
    return value is not None and bool(str(value).strip())


def _value_for(record: Mapping[str, object], aliases: tuple[str, ...]) -> object:
    for alias in aliases:
        value = record.get(alias.casefold())
        if _is_present(value):
            return value
    return ""


def batch_results(content: bytes, filename: str) -> tuple[bytes, int, int]:
    suffix = Path(filename).suffix.lower()
    if suffix == ".csv":
        headers, records = read_csv_rows(content)
    elif suffix == ".xlsx":
        headers, records = read_xlsx_rows(content, "Single_lap_batch", "Double_lap_batch")
    else:
        raise ValueError("Select an .xlsx or UTF-8 .csv file.")
    if not headers or not records:
        raise ValueError("The file does not contain any data rows.")

    columns = {header.casefold() for header in headers if header}
    missing = [
        key for key, aliases in INPUT_COLUMNS.items()
        if key not in {"Model_ID", "b_mm", "e2_mm"}
        and not any(alias.casefold() in columns for alias in aliases)
    ]
    if not any(alias.casefold() in columns for key in ("b_mm", "e2_mm") for alias in INPUT_COLUMNS[key]):
        missing.append("b_mm or e2_mm")
    if missing:
        raise ValueError("Input headers not found: " + ", ".join(missing) + ". Use the single-shear input template.")

    outputs = [name for pair in OUTPUT_COLUMNS.values() for name in pair]
    resistance_columns = {resistance for resistance, _ in OUTPUT_COLUMNS.values()}
    result_rows = []
    valid_rows = 0
    invalid_rows = 0
    for source_row, raw in records:
        lower = {key.casefold(): value for key, value in raw.items()}
        inputs = {key: _value_for(lower, aliases) for key, aliases in INPUT_COLUMNS.items()}
        if not any(_is_present(value) for value in inputs.values()):
            continue
        data = {key: inputs[column] for column, key in MODEL_FIELDS.items()}
        material = str(data["material"]).strip().upper()
        data["material"] = MATERIAL_CODES.get(material, material)

        try:
            normalized, predictions, warnings = calculate(data)
        except ValidationError as exc:
            result_rows.append([
                source_row, *inputs.values(), *([""] * len(outputs)), "", f"Row {source_row}: {exc}",
            ])
            invalid_rows += 1
            continue

        for column, key in MODEL_FIELDS.items():
            inputs[column] = data[key] if key == "material" else normalized[key]
        predicted = [item for key in OUTPUT_COLUMNS for item in predictions[key]]
        result_rows.append([source_row, *inputs.values(), *predicted, " ".join(warnings), ""])
        valid_rows += 1

    if not result_rows:
        raise ValueError("The file does not contain any single-shear input cases.")

    workbook = write_xlsx(
        ["Source_row", *INPUT_COLUMNS, *outputs, "Warnings", "Errors"],
        result_rows,
        "Single_shear_results",
        resistance_columns=resistance_columns,
    )
    return workbook, valid_rows, invalid_rows
